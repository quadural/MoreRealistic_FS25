Wheel.mrRegisterXMLPaths = function(schema, superFunc, key)
    superFunc(schema, key)
    --allow us to get the rim dimension in the WheelPhysics.mrLoadAdditionalWheel function
    schema:register(XMLValueType.VECTOR_2, key .. ".outerRim#widthAndDiam", "Rim dimension")
    local additionalWheelKey = key .. ".additionalWheel(?)"
    schema:register(XMLValueType.VECTOR_2, additionalWheelKey .. ".outerRim#widthAndDiam", "Rim dimension") -- fix xml load error in some mods (example : Belarus 920)
end
Wheel.registerXMLPaths = Utils.overwrittenFunction(Wheel.registerXMLPaths, Wheel.mrRegisterXMLPaths)
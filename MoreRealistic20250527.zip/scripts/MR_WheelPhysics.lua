WheelPhysics.mrNew = function(wheel, superFunc)

    local self = superFunc(wheel)

    self.mrTireGroundRollingResistanceCoeff = 0.01
    self.mrLastTireLoad = 0
    self.mrLastWheelSpeed = 0
    self.mrLastWheelSpeedS = 0
    self.mrLastLongSlip = 0
    self.mrLastLongSlipS = 0
    self.mrLastLatSlip = 0
    self.mrDynamicFrictionScale = 1
    self.mrDynamicFrictionScaleS = 1
    self.mrLastBrakeForce = 0
    self.mrIsDriven = false
    self.mrABS = false
    self.mrTotalWidth = 0

    return self

end
WheelPhysics.new = Utils.overwrittenFunction(WheelPhysics.new, WheelPhysics.mrNew)

WheelPhysics.mrRegisterXMLPaths = function(schema, superFunc, key)
    superFunc(schema, key)
    --add mrABS param
    schema:register(XMLValueType.BOOL, key .. ".physics#mrABS", "Prevent locking of the wheel uring braking", false)
end
WheelPhysics.registerXMLPaths = Utils.overwrittenFunction(WheelPhysics.registerXMLPaths, WheelPhysics.mrRegisterXMLPaths)


WheelPhysics.mrLoadFromXML = function(self, superFunc, xmlObject)
    --MR : wheels masses are a little bit "off" from Giants.
    --Example : 650/85R38, tyre + rim = 320kg + 180kg = about 530kg IRL (we can verify that by looking at https://shop.deere.com/ , or reading nebraska test reports
    --but base game mass of the whole wheel = 398kg
    --Some wheels are right though : for example, the "narrow" 480/80R50 wheels are set to 409kilos in the game (about 420kilos IRL)
    -- other data sources = https://www.allpneus.com/
    -- Problem = wheels masses are something very important in a tractor simulator, and so, we are trying to get some closer to IRL figures here
    if superFunc(self, xmlObject) then

        --override default "0.3" forcepointratio
        if self.vehicle.mrIsMrVehicle and self.forcePointRatio>=0.2999 and self.forcePointRatio<=0.3001 then
            self.forcePointRatio=0.5 --default MR forcePointValue (far from being realistic, we don't wan to penalize too much casual players)
        end

        --load mrABS
        self.mrABS = xmlObject:getValue(".physics#mrABS", false)

        --check if we can get a "better" wheel mass
        self.mrTotalWidth = self.width
        local rimDimension = xmlObject:getValue(".outerRim#widthAndDiam", nil, true)
        if rimDimension==nil then
            return true --do nothing if no rim present
        end
        local category = nil
        if xmlObject.externalXMLFile~=nil then
            category = xmlObject.externalXMLFile:getValue("wheel.metadata#category", nil, true)
        end
        local rimRadius = 0.5*MathUtil.inchToM(rimDimension[2])
        local newMass = WheelsUtil.mrGetMassFromDimension(self.width, self.radius, rimRadius, category)
        if newMass>0 then
            self.mass = newMass
            self.baseMass = self.mass
        end
        return true
    end
    return false
end
WheelPhysics.loadFromXML = Utils.overwrittenFunction(WheelPhysics.loadFromXML, WheelPhysics.mrLoadFromXML)

WheelPhysics.mrLoadAdditionalWheel = function(self, superFunc, xmlObject)
    superFunc(self, xmlObject)
    local xmlMass = xmlObject:getValue(".physics#mass", 0)
    local rimDimension = xmlObject:getValue(".outerRim#widthAndDiam", nil, true)
    local width = xmlObject:getValue(".physics#width", 0)
    local wheelRadius = xmlObject:getValue(".physics#radius", 0)

    if xmlMass>0 and rimDimension~=nil then
        --compute total wheel mass from tire and rim dimension
        local rimRadius = 0.5*MathUtil.inchToM(rimDimension[2])
        local category = nil
        if xmlObject.externalXMLFile~=nil then
            category = xmlObject.externalXMLFile:getValue("wheel.metadata#category", nil, true)
        end
        local newMass = WheelsUtil.mrGetMassFromDimension(width, wheelRadius, rimRadius, category)
        if newMass>0 then
            --1.33 factor because there is some addtionnal parts to attach dual/triple wheels to inner wheels (the rim can be different too)
            self.mass = self.mass - xmlMass + 1.33*newMass
        end
    end

    self.mrTotalWidth = self.mrTotalWidth + width

end
WheelPhysics.loadAdditionalWheel = Utils.overwrittenFunction(WheelPhysics.loadAdditionalWheel, WheelPhysics.mrLoadAdditionalWheel)

WheelPhysics.mrPostUpdate = function(self, dt)
    WheelPhysics.mrUpdateDynamicFriction(self, dt)
end
WheelPhysics.postUpdate = Utils.prependedFunction(WheelPhysics.postUpdate, WheelPhysics.mrPostUpdate)

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--
-- make use of mrDynamicFrictionScale instead of frictionScale
--
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
WheelPhysics.mrUpdateTireFriction = function(self, superFunc)
    if self.vehicle.isServer and self.vehicle.isAddedToPhysics then
        --test
--         self.maxLongStiffness = 300
--         self.maxLatStiffness = 5
--         self.maxLatStiffnessLoad = 1
        setWheelShapeTireFriction(self.wheel.node, self.wheelShape, self.maxLongStiffness, self.maxLatStiffness, self.maxLatStiffnessLoad, self.tireGroundFrictionCoeff*self.mrDynamicFrictionScale)
        self.isFrictionDirty = false
    end
end
WheelPhysics.updateTireFriction = Utils.overwrittenFunction(WheelPhysics.updateTireFriction, WheelPhysics.mrUpdateTireFriction)

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--
-- 20250525 - rely on tyre spec and current load now
--
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
WheelPhysics.mrUpdateDynamicFriction = function(self, dt)

    if self.mrIsDriven then
        if self.mrLastBrakeForce>0 then
            if self.mrDynamicFrictionScale>1.2 then
                self.mrDynamicFrictionScale = 1.2
                self.isFrictionDirty = true
            end
        else

            local minFx = 1.2
            local maxFx = 1.2
            local groundFx = 100

            if self.mrLastGroundType==WheelsUtil.GROUND_ROAD then
                maxFx = 3
                groundFx = 170
            elseif self.mrLastGroundType==WheelsUtil.GROUND_HARD_TERRAIN then
                maxFx = 2.7
                groundFx = 140
            elseif self.mrLastGroundType==WheelsUtil.GROUND_SOFT_TERRAIN then
                minFx = 1.1
                maxFx = 2.2
                groundFx = 110
            elseif self.mrLastGroundType==WheelsUtil.GROUND_FIELD then
                minFx = 1
                maxFx = 2.5 --more than soft because wheels are bouncing a lot on field
                groundFx = 80
            end

            local tyreFx = math.clamp(groundFx*self.mrTotalWidth*self.radius/math.max(0.1, self.mrLastTireLoad), minFx, maxFx)

            local curSpd = self.vehicle.lastSpeed*1000
            local newDynamicFrictionScale = 1
            if curSpd>=3 then --10.8kph
                newDynamicFrictionScale = tyreFx
            elseif curSpd>0.1 then --0.36kph
                local speedFx = minFx + (maxFx-minFx)*curSpd/3
                newDynamicFrictionScale = math.min(speedFx*tyreFx/maxFx, tyreFx)
            else
                newDynamicFrictionScale = tyreFx*minFx/maxFx
            end

            --20250515 - add some more friction when wheels are rotated
            newDynamicFrictionScale = newDynamicFrictionScale * (1+0.2*math.abs(self.steeringAngle))

            self.mrDynamicFrictionScaleS = 0.9*self.mrDynamicFrictionScaleS + 0.1*newDynamicFrictionScale

            if math.abs(self.mrDynamicFrictionScaleS-self.mrDynamicFrictionScale)>0.02 then
                self.mrDynamicFrictionScale = self.mrDynamicFrictionScaleS
                self.isFrictionDirty = true
            end
        end

    else
        --not mrIsDriven
        local wantedFriction = 1.2 * math.clamp(self.vehicle.lastSpeed*240, 1, 2) --x2 @30kph
        if math.abs(self.mrDynamicFrictionScale-wantedFriction)>0.1 then
            self.isFrictionDirty = true
            self.mrDynamicFrictionScale = wantedFriction
        end
    end
end








WheelPhysics.mrGetRollingResistance = function(self, wheelSpeed, tireLoad, rrCoeff)
    -- rolling resistance = coeff * normal force
    -- simplified model for rr
    -- +14.44% rr @40kph (11m/s)

    --take into account wheel "crushed" under load => more rr if the wheel is "deformed"
    --this is especially relevant on soft ground
    local rrFx = 1
    if self.mrTotalWidth>0 then
        local groundWetness = g_currentMission.environment.weather:getGroundWetness()
        WheelPhysics.mrGetRrFx(self.mrTotalWidth, self.radius, self.mrLastTireLoad, self.mrLastGroundType, groundWetness)
    end
    --depend on surface (soft and field)

    --20250514 - only 1% rr at still to avoid strange behavior when tractor is not heavy enough to pull a trailer on hilly road or muddy field
    --full rr @1.782kph
    local startFx = math.min(1, 0.01 + 2*math.abs(wheelSpeed))
    return (startFx+0.013*math.abs(wheelSpeed)) * tireLoad * rrCoeff * rrFx
end

WheelPhysics.mrGetPressureFx = function(width, radius, load)
    local contactPatch = width * radius * 0.5236 -- 2*pi*r/12 (ideal deformation of the wheel = about 1/12 of circonference)
    if contactPatch>0 and load>0 then
        return load / (373*contactPatch^2) -- magic formula = load(T) / patch² / 38
    end
    return 0
end

WheelPhysics.mrGetRrFx = function(width, radius, load, groundType, wetness)
    local rrFx = 1
    wetness = wetness^0.5
    if groundType==WheelsUtil.GROUND_FIELD then
        local pressureFx = WheelPhysics.mrGetPressureFx(width, radius, load)
        rrFx = math.max(0.8, 0.05*wetness+(pressureFx/(1.5-0.7*wetness))^(0.15+0.1*wetness))
    elseif groundType==WheelsUtil.GROUND_SOFT_TERRAIN then
        local pressureFx = WheelPhysics.mrGetPressureFx(width, radius, load)
        rrFx = math.max(0.8, 0.05*wetness+(pressureFx/(2-0.8*wetness))^(0.12+0.06*wetness))
    end
    return rrFx
end

WheelPhysics.mrUpdatePhysics = function(self, superFunc, brakeForce, torque)
    if self.vehicle.isServer and self.vehicle.isAddedToPhysics then

        local damping = 0.03 * self.mass
        local bForce = 0
        local rrForce = 0
        local engineBrakeForce = 0
        if not self.wheelShapeCreated then
            bForce = brakeForce
        else
            local tireLoad = getWheelShapeContactForce(self.wheel.node, self.wheelShape)
            local wheelSpeed = 0

            if tireLoad==nil then
                tireLoad =0
            end

            if self.hasGroundContact then
                local wheelWeight =  self.wheel:getMass() * 9.81 --do not take into account direction of the contact normal (not significant compared to the total mass of the vehicle. A great incline on the road = something like 10% IRL => only 5.71 degree)

                --update wheel speed (m/s)
                wheelSpeed = getWheelShapeAxleSpeed(self.wheel.node, self.wheelShape) * self.radius
                wheelSpeed = wheelSpeed or 0 --m/s

                if self.mrIsDriven then
                    --update wheel slip
                    self.mrLastLongSlip, self.mrLastLatSlip = getWheelShapeSlip(self.wheel.node, self.wheelShape)
                    self.mrLastLongSlipS = self.mrLastLongSlipS * 0.9 + self.mrLastLongSlip * 0.1
                    damping = 0.05 * self.mass * math.clamp(self.mrLastLongSlipS, 0, 1)
                end
                rrForce = WheelPhysics.mrGetRollingResistance(self, wheelSpeed, tireLoad+0.75*wheelWeight, self.mrTireGroundRollingResistanceCoeff) --20250516 - do not take the full wheel weight for rolling resistance
                tireLoad = tireLoad + wheelWeight
            end
            self.mrLastTireLoad = tireLoad
            self.mrLastWheelSpeedS = 0.9*self.mrLastWheelSpeedS + 0.1*wheelSpeed
            self.mrLastWheelSpeed = wheelSpeed

            --limit brakeforce to normal force * friction to avoid blocking wheel => ALB (auto load balance / anti lock brake regulator)
            if brakeForce>0 then
                bForce = brakeForce * self.brakeFactor
            end

            if self.mrIsDriven and self.vehicle.spec_motorized.mrEngineBrakingPowerToApply>0 then
                if self.mrLastTireLoad>0 and self.vehicle.spec_wheels.mrTotalWeightOnDrivenWheels>0 then
                    --force * speed = power => force = power / speed
                    local engineBrake = self.vehicle.spec_motorized.mrEngineBrakingPowerToApply*self.mrLastTireLoad/self.vehicle.spec_wheels.mrTotalWeightOnDrivenWheels
                    --max engine brake "power" down to 3mph
                    engineBrakeForce = engineBrake/math.max(3, math.abs(wheelSpeed))
                end
            end

        end

        self.mrLastBrakeForce = bForce

        local totalForce = rrForce+bForce+engineBrakeForce

        --limit brakeforce to normal force * friction to avoid blocking wheel => ALB (auto load balance / anti lock brake regulator)
        if self.wheelShapeCreated and (self.mrIsDriven or self.mrABS) then
            if totalForce>self.restLoad then --minimum force = restLoad (10% of restLoad weight since normal (vertical) force = 9.81*restload)
                totalForce = math.min(totalForce, self.mrLastTireLoad*self.tireGroundFrictionCoeff) --mini = about 50% of restLoad normal force
                totalForce = math.max(totalForce, self.restLoad)
            end
        end

        --brakeForce to force = value * radius (in fact, brakeForce param of this function = brake torque => force * radius = torque)
        setWheelShapeProps(self.wheel.node, self.wheelShape, 0, totalForce*self.radius, self.steeringAngle, damping)

        --brakeForce = 0
        --setWheelShapeAutoHoldBrakeForce(self.wheel.node, self.wheelShape, (bForce or 0) * self.autoHoldBrakeFactor) --what for ?

    end
end
WheelPhysics.updatePhysics = Utils.overwrittenFunction(WheelPhysics.updatePhysics, WheelPhysics.mrUpdatePhysics)



WheelPhysics.mrUpdateFriction= function(self, superFunc, dt, groundWetness)
    local isOnField = self.densityType ~= FieldGroundType.NONE

    local snowScale = 0
    if self.hasSnowContact then
        groundWetness = 0
        snowScale = 1
    else
        groundWetness = groundWetness^0.5
    end

    local groundType = WheelsUtil.mrGetGroundType(isOnField, self.contact ~= WheelContactType.GROUND, self.groundDepth, self.densityType, self.lastTerrainAttribute)
    local coeff = WheelsUtil.getTireFriction(self.tireType, groundType, groundWetness, snowScale)

    self.mrLastGroundType = groundType
    self.mrLastFrictionCoeff = coeff

    local lastSpeed = self.vehicle:getLastSpeed() --kph

    if lastSpeed>0.2 or self.mrLastWheelSpeedS>0.1 then
        if coeff ~= self.tireGroundFrictionCoeff then
            self.tireGroundFrictionCoeff = coeff
            self.isFrictionDirty = true
            --MR : update rolling resistance coeff too
            self.mrTireGroundRollingResistanceCoeff = WheelsUtil.mrGetTireRollingResistance(self.tireType, groundType, groundWetness, snowScale)
        end
    end

end
WheelPhysics.updateFriction = Utils.overwrittenFunction(WheelPhysics.updateFriction, WheelPhysics.mrUpdateFriction)
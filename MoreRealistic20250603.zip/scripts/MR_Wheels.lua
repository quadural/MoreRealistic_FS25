Wheels.mrOnLoad = function(self, savegame)
    self.spec_wheels.mrTotalWeightOnDrivenWheels = 0
    self.spec_wheels.mrNbDrivenWheels = 0
    self.spec_wheels.mrAvgDrivenWheelsSpeed = 0
end
Wheels.onLoad = Utils.appendedFunction(Wheels.onLoad, Wheels.mrOnLoad)
StoreManager.mrLoadItem = function(self, superFunc, rawXMLFilename, baseDir, customEnvironment, isMod, isBundleItem, dlcTitle, extraContentId, ignoreAdd)

    if baseDir=="" or dlcTitle~="" then

        local item = RealisticUtils.getOverridingXmlFileNameData(rawXMLFilename)

        if item~=nil then
            local mrConfigFileName = item.newFileName

            --20250614 -store the full path of the item too (indeed, for DLC vehicle by example, once loaded, the full path is the index // vanilla game => index=relative path)
            local fullFileName = baseDir .. rawXMLFilename
            if RealisticUtils.defaultVehiclesModifiedData[fullFileName]==nil then
                RealisticUtils.defaultVehiclesModifiedData[fullFileName] = item
            end
            --override value with full path
            if baseDir~="" then
                RealisticUtils.defaultVehicleMrFilenameToGenuineFilename[mrConfigFileName] = fullFileName
            end

            --20250613 - we want to keep "cutomEnvironment" and "baseDir" (function Vehicle:setFileName // Utils.getModNameAndBaseDirectory)
            if item.keepEnvironment then
                RealisticUtils.defaultVehiclesKeepEnvironmentTable[mrConfigFileName] = fullFileName
                rawXMLFilename = "$" .. mrConfigFileName -- $ tells the game not to concatenate baseDir and xmlfile path
            else
                rawXMLFilename = mrConfigFileName
            end
        end
--     elseif dlcTitle~="" then
--         --DLC vehicles
--         local mrConfigFileName = RealisticUtils.getOverridingXmlFileName(rawXMLFilename)
--         if mrConfigFileName~=nil then

-- --             local xmlFilename = Utils.getFilename(rawXMLFilename, baseDir)
-- --             local xmlFile = loadXMLFile("storeItemXML", xmlFilename)
-- --             local xmlString = saveXMLFileToMemory(xmlFile)
-- --             print(xmlString)
-- --             delete(xmlFile)

--             --rawXMLFilename = "$mods/" .. mrConfigFileName
--             --rawXMLFilename = "$mods/MoreRealistic/data/overriding/vehicles/versatile/series900.xml"

--              --store genuine rawXMLFilename
--               RealisticUtils.test1[mrConfigFileName] = baseDir..rawXMLFilename

--               rawXMLFilename = "$" .. mrConfigFileName
--         end
    end

    local storeItem = superFunc(self, rawXMLFilename, baseDir, customEnvironment, isMod, isBundleItem, dlcTitle, extraContentId, ignoreAdd)

    if storeItem~=nil then
        --check if MR tag is present
        local xmlFilename = Utils.getFilename(rawXMLFilename, baseDir)
        local xmlFile = loadXMLFile("storeItemXML", xmlFilename)
        local isMrVehicle = getXMLBool(xmlFile, "vehicle.MR") or false
        delete(xmlFile)
        if isMrVehicle then
            storeItem.name = "MR " .. storeItem.name
        end
    end

    return storeItem
end
StoreManager.loadItem = Utils.overwrittenFunction(StoreManager.loadItem, StoreManager.mrLoadItem)


StoreManager.mrAddPackItem = function(self, superFunc, name, itemFilename)
    local item = RealisticUtils.getOverridingXmlFileNameData(itemFilename)
    if item~=nil then
        itemFilename = item.newFileName
    end

    return superFunc(self, name, itemFilename)
end
StoreManager.addPackItem = Utils.overwrittenFunction(StoreManager.addPackItem, StoreManager.mrAddPackItem)

StoreManager.mrGetItemByXMLFilename = function(self, superFunc, xmlFilename)
    if xmlFilename ~= nil then
        --check if MR version is present
        local item = RealisticUtils.getOverridingXmlFileNameData(xmlFilename)
        if item~=nil then
            xmlFilename = item.newFileName
        end
    end

    return superFunc(self, xmlFilename)
end
StoreManager.getItemByXMLFilename = Utils.overwrittenFunction(StoreManager.getItemByXMLFilename, StoreManager.mrGetItemByXMLFilename)
WheelPhysics.mrNew = function(wheel, superFunc)

    local self = superFunc(wheel)

    self.mrTireGroundRollingResistanceCoeff = 0.01
    self.mrLastTireLoad = 0
    self.mrLastWheelSpeed = 0
    self.mrLastWheelSpeedS = 0
    self.mrLastLongSlip = 0
    self.mrLastLongSlipS = 0
    self.mrLastLatSlip = 0
    self.mrDynamicFrictionScale = 1
    self.mrDynamicFrictionScaleS = 1
    self.mrLastBrakeForce = 0
    self.mrIsDriven = false
    self.mrABS = false
    self.mrTotalWidth = 0
    self.mrFrictionNeedUpdate = true
    self.mrLastRrFx = 0
    self.mrLastContactNormalRatio = 1

    return self

end
WheelPhysics.new = Utils.overwrittenFunction(WheelPhysics.new, WheelPhysics.mrNew)

WheelPhysics.mrRegisterXMLPaths = function(schema, superFunc, key)
    superFunc(schema, key)
    --add mrABS param
    schema:register(XMLValueType.BOOL, key .. ".physics#mrABS", "Prevent locking of the wheel uring braking", false)
    schema:register(XMLValueType.BOOL, key .. ".physics#mrKeepMass", "Prevent replacing xml mass with mr autocompute wheel mass", false)
    schema:register(XMLValueType.FLOAT, key .. ".physics#mrFrictionScale", "Allow to set a given friction scale")

end
WheelPhysics.registerXMLPaths = Utils.overwrittenFunction(WheelPhysics.registerXMLPaths, WheelPhysics.mrRegisterXMLPaths)


WheelPhysics.mrLoadFromXML = function(self, superFunc, xmlObject)
    --MR : wheels masses are a little bit "off" from Giants.
    --Example : 650/85R38, tyre + rim = 320kg + 180kg = about 530kg IRL (we can verify that by looking at https://shop.deere.com/ , or reading nebraska test reports
    --but base game mass of the whole wheel = 398kg
    --Some wheels are right though : for example, the "narrow" 480/80R50 wheels are set to 409kilos in the game (about 420kilos IRL)
    -- other data sources = https://www.allpneus.com/
    -- Problem = wheels masses are something very important in a tractor simulator, and so, we are trying to get some closer to IRL figures here
    if superFunc(self, xmlObject) then

        --override default "0.3" forcepointratio
--         if self.vehicle.mrIsMrVehicle and self.forcePointRatio>=0.2999 and self.forcePointRatio<=0.3001 then
--             self.forcePointRatio=0.5 --default MR forcePointValue (far from being realistic, we don't want to penalize too much casual players)
--         end
        if self.vehicle.mrIsMrVehicle and self.radius>=0.2 then
            --we want the force point about 10cm above the ground
            self.forcePointRatio = (self.radius-0.1)/self.radius
        end

        self.mrTotalWidth = self.width

        --add some randomness to the damping value
        self.rotationDamping = (0.5+math.random())*self.rotationDamping --80% to 120% base value

        --load mrABS
        self.mrABS = xmlObject:getValue(".physics#mrABS", false)

        self.mrFrictionScale = xmlObject:getValue(".physics#mrFrictionScale")

        --check if we override base game mass by self-computed MR mass
        local keepMass = xmlObject:getValue(".physics#mrKeepMass", false)
        if not keepMass then
            --check if we can get a "better" wheel mass
            local rimDimension = xmlObject:getValue(".outerRim#widthAndDiam", nil, true)
            if rimDimension~=nil then
                local category = nil
                if xmlObject.externalXMLFile~=nil then
                    category = xmlObject.externalXMLFile:getValue("wheel.metadata#category", nil, true)
                end
                local rimRadius = 0.5*MathUtil.inchToM(rimDimension[2])
                local newMass = WheelsUtil.mrGetMassFromDimension(self.width, self.radius, rimRadius, category)
                if newMass>0 then
                    self.mass = newMass
                    self.baseMass = self.mass
                end
            end
        end

        return true
    end
    return false
end
WheelPhysics.loadFromXML = Utils.overwrittenFunction(WheelPhysics.loadFromXML, WheelPhysics.mrLoadFromXML)

WheelPhysics.mrLoadAdditionalWheel = function(self, superFunc, xmlObject)
    superFunc(self, xmlObject)
    local xmlMass = xmlObject:getValue(".physics#mass", 0)
    local rimDimension = xmlObject:getValue(".outerRim#widthAndDiam", nil, true)
    local width = xmlObject:getValue(".physics#width", 0)
    local wheelRadius = xmlObject:getValue(".physics#radius", 0)

    if xmlMass>0 and rimDimension~=nil then
        --compute total wheel mass from tire and rim dimension
        local rimRadius = 0.5*MathUtil.inchToM(rimDimension[2])
        local category = nil
        if xmlObject.externalXMLFile~=nil then
            category = xmlObject.externalXMLFile:getValue("wheel.metadata#category", nil, true)
        end
        local newMass = WheelsUtil.mrGetMassFromDimension(width, wheelRadius, rimRadius, category)
        if newMass>0 then
            --1.33 factor because there is some addtionnal parts to attach dual/triple wheels to inner wheels (the rim can be different too)
            self.mass = self.mass - xmlMass + 1.33*newMass
        end
    end

    self.mrTotalWidth = self.mrTotalWidth + width

end
WheelPhysics.loadAdditionalWheel = Utils.overwrittenFunction(WheelPhysics.loadAdditionalWheel, WheelPhysics.mrLoadAdditionalWheel)

WheelPhysics.mrPostUpdate = function(self, dt)
    WheelPhysics.mrUpdateDynamicFriction(self, dt)
end
WheelPhysics.postUpdate = Utils.prependedFunction(WheelPhysics.postUpdate, WheelPhysics.mrPostUpdate)

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--
-- make use of mrDynamicFrictionScale instead of frictionScale
--
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
WheelPhysics.mrUpdateTireFriction = function(self, superFunc)
    if self.vehicle.isServer and self.vehicle.isAddedToPhysics then
        --test
--         self.maxLongStiffness = 300
--         self.maxLatStiffness = 5
--         self.maxLatStiffnessLoad = 1
        setWheelShapeTireFriction(self.wheel.node, self.wheelShape, self.maxLongStiffness, self.maxLatStiffness, self.maxLatStiffnessLoad, self.tireGroundFrictionCoeff*self.mrDynamicFrictionScale)
        self.isFrictionDirty = false
    end
end
WheelPhysics.updateTireFriction = Utils.overwrittenFunction(WheelPhysics.updateTireFriction, WheelPhysics.mrUpdateTireFriction)

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--
-- 20250525 - rely on tyre spec and current load now
--
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
WheelPhysics.mrUpdateDynamicFriction = function(self, dt)

    if self.mrFrictionScale~=nil then
        self.mrDynamicFrictionScale = self.mrFrictionScale
        return
    end

    if self.mrIsDriven then
        if self.mrLastBrakeForce>0 then
            if self.mrDynamicFrictionScale>1.2 then
                self.mrDynamicFrictionScale = 1.2
                self.isFrictionDirty = true
            end
        else

            local minFx = 1.2
            local maxFx = 1.2
            local groundFx = 100
            local spd0 = 3

            if self.hasSnowContact then
                minFx = 1
                maxFx = 1.2
                groundFx = 70
            else
                if self.mrLastGroundType==WheelsUtil.GROUND_ROAD then
                    maxFx = 3
                    groundFx = 180
                    spd0 = 2 -- reach max friction at lower speed
                elseif self.mrLastGroundType==WheelsUtil.GROUND_HARD_TERRAIN then
                    maxFx = 2.7
                    groundFx = 140
                elseif self.mrLastGroundType==WheelsUtil.GROUND_SOFT_TERRAIN then
                    minFx = 1.1
                    maxFx = 2.2
                    groundFx = 110

                    --20250623 - limit maxFx if too much slipping
                    if self.mrLastLongSlipS>0.35 then
                        maxFx = (0.35/self.mrLastLongSlipS)*maxFx
                    end

                elseif self.mrLastGroundType==WheelsUtil.GROUND_FIELD then
                    if self.mrLastGroundSubType==1 then --firmer ground field (eg: harvest state)
                        minFx = 1
                        maxFx = 2.3
                        groundFx = 90
                    else
                        minFx = 1
                        maxFx = 2.5 --more than soft because wheels are bouncing a lot on field
                        groundFx = 80
                    end

                    --20250623 - limit maxFx if too much slipping
                    if self.mrLastLongSlipS>0.25 then
                        maxFx = (0.25/self.mrLastLongSlipS)*maxFx
                    end

                end

                local groundWetness = g_currentMission.environment.weather:getGroundWetness()
                --50% less maxFx when wetness=1
                if groundWetness>0.01 then
                    maxFx = (1-0.5*groundWetness)*maxFx
                end

                maxFx = math.max(maxFx, minFx)

            end

            local tyreFx = groundFx*self.mrTotalWidth*self.radius/math.max(0.1, self.mrLastTireLoad)
            tyreFx = math.clamp(tyreFx, minFx, maxFx)
            local curSpd = self.vehicle.lastSpeed*1000
            local newDynamicFrictionScale = 1
            --we want to get tyreFx*minFx/maxFx at speed lower than 0.1m/s, then we want to reach tyreFx at spd0 m/s
--             if curSpd>=spd0 then --10.8kph
--                 newDynamicFrictionScale = tyreFx
--             elseif curSpd>0.1 then --0.36kph
--                 local mm = minFx/maxFx
--                 local a0 = tyreFx*(1-mm)/(spd0-0.1)
--                 local speedFx = math.min(1, mm + a0*curSpd)
--                 newDynamicFrictionScale = speedFx*tyreFx
--             else
--                 newDynamicFrictionScale = tyreFx*minFx/maxFx
--             end

            --we want to get tyreFx*0.8 at speed lower than 0.1m/s, then we want to reach tyreFx at spd0 m/s
            if curSpd>=spd0 then --10.8kph
                newDynamicFrictionScale = tyreFx
            elseif curSpd>0.1 then --0.36kph
                local a0 = 0.2/(spd0-0.1)
                local speedFx = 0.8 + a0*(curSpd-0.1)
                newDynamicFrictionScale = speedFx*tyreFx
            else
                newDynamicFrictionScale = math.max(tyreFx*0.8, minFx)
            end

            --20250601 - limit newDynamicFrictionScale at low speed (against a wall for example)
            newDynamicFrictionScale = math.min(newDynamicFrictionScale, math.max(minFx, math.abs(self.mrLastWheelSpeed)))

            --20250515 - add some more friction when wheels are rotated
            newDynamicFrictionScale = newDynamicFrictionScale * (1+0.2*math.abs(self.steeringAngle))

            --20250701 - add contact normal ratio
            newDynamicFrictionScale = math.max(self.mrLastContactNormalRatio*newDynamicFrictionScale, minFx)

            self.mrDynamicFrictionScaleS = 0.9*self.mrDynamicFrictionScaleS + 0.1*newDynamicFrictionScale

            if math.abs(self.mrDynamicFrictionScaleS-self.mrDynamicFrictionScale)>0.02 then
                self.mrDynamicFrictionScale = self.mrDynamicFrictionScaleS
                self.isFrictionDirty = true
            end
        end

    else
        --not mrIsDriven
        local wantedFriction = 1.2 * math.clamp(self.vehicle.lastSpeed*240, 1, 2) --x2 @30kph
        if math.abs(self.mrDynamicFrictionScale-wantedFriction)>0.1 then
            self.isFrictionDirty = true
            self.mrDynamicFrictionScale = wantedFriction
        end
    end
end








WheelPhysics.mrGetRollingResistance = function(self, wheelSpeed, tireLoad, rrCoeff)
    -- rolling resistance = coeff * normal force
    -- simplified model for rr
    -- +14.44% rr @40kph (11m/s)

    --take into account wheel "crushed" under load => more rr if the wheel is "deformed"
    --this is especially relevant on soft ground
    local rrFx = 1
    if self.mrTotalWidth>0 then
        local groundWetness = g_currentMission.environment.weather:getGroundWetness()
        rrFx = WheelPhysics.mrGetRrFx(self.mrTotalWidth, self.radius, self.mrLastTireLoad, self.mrLastGroundType, self.mrLastGroundSubType, groundWetness)
    end
    self.mrLastRrFx = rrFx
    --depend on surface (soft and field)

    --20250514 - only 10% rr at still to avoid strange behavior when tractor is not heavy enough to pull a trailer on hilly road or muddy field => only for not driven wheels
    --full rr @1.782kph
    --at very low speed, we rely on high wheel damping to simulate rolling resistance
    local startFx = 1
    if not self.mrIsDriven then
        startFx = math.min(1, 0.1 + 1.8*math.abs(wheelSpeed))
    end

    return (startFx+0.013*math.abs(wheelSpeed)) * tireLoad * rrCoeff * rrFx
end

WheelPhysics.mrGetPressureFx = function(width, radius, load)
    local contactPatch = width * radius * 0.5236 -- 2*pi*r/12 (ideal deformation of the wheel = about 1/12 of circonference)
    if contactPatch>0 and load>0 then
        return load / (373*contactPatch^2) -- magic formula = load(T) / patch² / 38
    end
    return 0
end


WheelPhysics.mrGetDryFx = function(pressureFx, groundType, groundSubType)
    local fx = 1
    if groundType==WheelsUtil.GROUND_FIELD then
        --loose field ground type
        if groundSubType==0 then
            if pressureFx<=2 then
                fx = 0.8+pressureFx*0.1
            else
                fx = 0.75+pressureFx*0.125
            end
        else
            --firmer field ground type
            if pressureFx<=2.6 then
                fx = 0.805+pressureFx*0.075
            else
                fx = 0.7582+pressureFx*0.093
            end
        end
    elseif groundType==WheelsUtil.GROUND_SOFT_TERRAIN then
        if pressureFx<=3.2 then
            fx = 0.8+pressureFx*0.0625
        else
            fx = 0.744+pressureFx*0.08
        end
    end
    return fx
end

WheelPhysics.mrGetWetFx = function(pressureFx, groundType, groundSubType)
    local fx = 1
    if groundType==WheelsUtil.GROUND_FIELD then
    --loose field ground type
        if groundSubType==0 then
            if pressureFx<=1 then
                fx = 0.8+pressureFx*0.2
            else
                fx = 0.67+pressureFx*0.33
            end
        else
            --firmer field ground type
            if pressureFx<=1.2 then
                fx = 0.796+pressureFx*0.17
            else
                fx = 0.736+pressureFx*0.22
            end
        end
    elseif groundType==WheelsUtil.GROUND_SOFT_TERRAIN then
        if pressureFx<=1.5 then
            fx = 0.805+pressureFx*0.13
        else
            fx = 0.745+pressureFx*0.17
        end
    end
    return fx
end


WheelPhysics.mrGetRrFx = function(width, radius, load, groundType, groundSubType, wetness)
    local rrFx = 1
    wetness = wetness^0.5
    if groundType==WheelsUtil.GROUND_FIELD or groundType==WheelsUtil.GROUND_SOFT_TERRAIN then
        local pressureFx = WheelPhysics.mrGetPressureFx(width, radius, load)
        --limit max pressure (IRL, there would be no difference between 6bars or 20bars in bad conditions)
        pressureFx = math.min(pressureFx, 6)
        if wetness==0 then
            rrFx = WheelPhysics.mrGetDryFx(pressureFx, groundType, groundSubType)
        elseif wetness==1 then
            rrFx = WheelPhysics.mrGetWetFx(pressureFx, groundType, groundSubType)
        else --in between wetness
            rrFx = (1-wetness) * WheelPhysics.mrGetDryFx(pressureFx, groundType, groundSubType) + wetness * WheelPhysics.mrGetWetFx(pressureFx, groundType, groundSubType)
        end
    end
    return rrFx
end

WheelPhysics.mrUpdatePhysics = function(self, superFunc, brakeForce, torque)
    if self.vehicle.isServer and self.vehicle.isAddedToPhysics then

        local damping = 0.03 * self.mass
        local bForce = 0
        local rrForce = 0
        local engineBrakeForce = 0
        if not self.wheelShapeCreated then
            bForce = brakeForce
        else
            local tireLoad = getWheelShapeContactForce(self.wheel.node, self.wheelShape)
            local wheelSpeed = 0

            if tireLoad==nil then
                tireLoad =0
            end

            if self.hasGroundContact then
                local wheelWeight =  self.wheel:getMass() * 9.81 --do not take into account direction of the contact normal (not significant compared to the total mass of the vehicle. A great incline on the road = something like 10% IRL => only 5.71 degree)

                --update wheel speed (m/s)
                wheelSpeed = getWheelShapeAxleSpeed(self.wheel.node, self.wheelShape) * self.radius
                wheelSpeed = wheelSpeed or 0 --m/s

                if self.mrIsDriven then
                    --update wheel slip
                    self.mrLastLongSlip, self.mrLastLatSlip = getWheelShapeSlip(self.wheel.node, self.wheelShape)
                    self.mrLastLongSlipS = self.mrLastLongSlipS * 0.9 + self.mrLastLongSlip * 0.1
                    damping = 0.05 * math.clamp(self.mrLastLongSlipS, 0, 1) --more damping when slipping
                    damping = self.mass * math.max(0.03, damping) -- but always a minimum damping

                    --20250609 - trying to help the differential system to stabilize
                    -- when it goes crazy, we lose a lot of power (Eg : frame1 => wheel left = 50rpm and wheel right = 10rpm // frame2 => wheel left = 10rpm and wheel right = 50rpm // etc, etc,etc)
                    -- best example I could see = MT655 going at 7-8kph with lemken smaragdt (shallow mode) instead of 10-12kph (for no reason, wetness was 0, and 95% of the field was done at the right speed)
                    if wheelSpeed>1 and wheelSpeed>1.5*self.vehicle.spec_wheels.mrAvgDrivenWheelsSpeed then
                        damping = damping * 2
                    end

                    --20250701 - adding getWheelShapeContactNormal to help get better result for dynamicFrictionScale
                    local _,ny,_ = getWheelShapeContactNormal(self.wheel.node, self.wheelShape)
                    if ny~=nil then
                        self.mrLastContactNormalRatio = ny
                    else
                        self.mrLastContactNormalRatio = 1
                    end
                end
                rrForce = WheelPhysics.mrGetRollingResistance(self, wheelSpeed, tireLoad+0.75*wheelWeight, self.mrTireGroundRollingResistanceCoeff) --20250516 - do not take the full wheel weight for rolling resistance
                tireLoad = tireLoad + wheelWeight
            else
                --no ground contact = "random" damping (sse loadFromXML)
                damping = self.rotationDamping
            end
            self.mrLastTireLoad = tireLoad
            self.mrLastWheelSpeedS = 0.9*self.mrLastWheelSpeedS + 0.1*wheelSpeed
            self.mrLastWheelSpeed = wheelSpeed

            --limit brakeforce to normal force * friction to avoid blocking wheel => ALB (auto load balance / anti lock brake regulator)
            if brakeForce>0 and self.brakeFactor>0 then
                bForce = brakeForce * self.brakeFactor
            end

            if self.mrIsDriven and self.vehicle.spec_motorized.mrEngineBrakingPowerToApply>0 then
                if self.mrLastTireLoad>0 and self.vehicle.spec_wheels.mrTotalWeightOnDrivenWheels>0 then
                    --force * speed = power => force = power / speed
                    local engineBrake = self.vehicle.spec_motorized.mrEngineBrakingPowerToApply*self.mrLastTireLoad/self.vehicle.spec_wheels.mrTotalWeightOnDrivenWheels
                    --max engine brake "power" down to 3mph
                    engineBrakeForce = engineBrake/math.max(3, math.abs(wheelSpeed))
                end
            end

        end

        self.mrLastBrakeForce = bForce

        local totalForce = rrForce+bForce+engineBrakeForce

        --limit brakeforce to normal force * friction to avoid blocking wheel => ALB (auto load balance / anti lock brake regulator)
        if self.wheelShapeCreated and (self.mrIsDriven or self.mrABS) then
            if totalForce>self.restLoad then --minimum force = restLoad (10% of restLoad weight since normal (vertical) force = 9.81*restload)
                totalForce = math.min(totalForce, self.mrLastTireLoad*self.tireGroundFrictionCoeff)
                totalForce = math.max(totalForce, self.restLoad)
            end
        end

        --20250601 - increase damping at low speed
        local lastSpeed = self.vehicle:getLastSpeed() --kph
        if lastSpeed<3 then
            damping = (100-33*lastSpeed)*damping --we want to simulate rolling resistance here since this is not really possible at very low speed with forces
        end


        --brakeForce to force = value * radius (in fact, brakeForce param of this function = brake torque => force * radius = torque)
        setWheelShapeProps(self.wheel.node, self.wheelShape, 0, totalForce*self.radius, self.steeringAngle, damping)

        --brakeForce = 0
        --setWheelShapeAutoHoldBrakeForce(self.wheel.node, self.wheelShape, (bForce or 0) * self.autoHoldBrakeFactor) --what for ?

    end
end
WheelPhysics.updatePhysics = Utils.overwrittenFunction(WheelPhysics.updatePhysics, WheelPhysics.mrUpdatePhysics)



WheelPhysics.mrUpdateFriction= function(self, superFunc, dt, groundWetness)

    local lastSpeed = self.vehicle:getLastSpeed() --kph
    if lastSpeed>0.2 or self.mrLastWheelSpeedS>0.1 then
        self.mrFrictionNeedUpdate = true
    end

    if self.mrFrictionNeedUpdate then

        local isOnField = self.densityType ~= FieldGroundType.NONE

        local snowScale = 0
        if self.hasSnowContact then
            groundWetness = 0
            snowScale = 1
        else
            groundWetness = groundWetness^0.5
        end

        local groundType, groundSubType = WheelsUtil.mrGetGroundType(isOnField, self.contact ~= WheelContactType.GROUND, self.groundDepth, self.densityType, self.lastTerrainAttribute)
        local coeff = WheelsUtil.getTireFriction(self.tireType, groundType, groundWetness, snowScale)

        self.mrLastGroundSubType = groundSubType
        self.mrLastGroundType = groundType
        self.mrLastFrictionCoeff = coeff

        self.mrFrictionNeedUpdate = false

        if coeff ~= self.tireGroundFrictionCoeff then
            self.tireGroundFrictionCoeff = coeff
            self.isFrictionDirty = true
            --MR : update rolling resistance coeff too
            self.mrTireGroundRollingResistanceCoeff = WheelsUtil.mrGetTireRollingResistance(self.tireType, groundType, groundWetness, snowScale)
        end

    end

end
WheelPhysics.updateFriction = Utils.overwrittenFunction(WheelPhysics.updateFriction, WheelPhysics.mrUpdateFriction)


---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--
-- apply RealisticMain.COMBINE_CAPACITY_FX factor to combine harvester pipe discharge speed
-- otherwise, in high yeld crops, the grain tank is filling "faster" than the pipe unloading rate (not true, but we could gain 20-25% more than the full grain tank until the pipe has finished unloading
--
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Combine.mrOnPostLoad = function(self, superFunc, savegame)

    superFunc(self, savegame)

    if self.mrIsMrCombine and self.spec_dischargeable~=nil then
        for i=1, #self.spec_dischargeable.dischargeNodes do
            self.spec_dischargeable.dischargeNodes[i].emptySpeed = self.spec_dischargeable.dischargeNodes[i].emptySpeed * RealisticMain.COMBINE_CAPACITY_FX
        end
    end

end
Combine.onPostLoad = Utils.overwrittenFunction(Combine.onPostLoad, Combine.mrOnPostLoad)

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--
-- apply power consumption function of Ton per hour
-- try to set the best speed limit (near the limit of the combine with the current header and crop)
-- take into account the yield => poor yield = high harvesting speed / best yield = lower harvesting speed)
--
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Combine.mrGetActiveConsumedPtoPower = function(self)
    local spec = self.spec_combine
    local isTurnedOn = self:getIsTurnedOn()
    local neededPower = 0

    --pipe
    if self.spec_dischargeable.currentDischargeState~=Dischargeable.DISCHARGE_STATE_OFF then
        neededPower = neededPower + self.mrCombineUnloadingPower
    end

    if isTurnedOn then

        local fruitCapacityFx = 1
        local fruitThreshingFx = 1
        local fruitChopperFx = 1

        local fruitTypeDesc = nil

        --get fruit capacityFx, ThreshingFx and ChopperFx from FruitTypeDesc
        if spec.lastCuttersInputFruitType~=nil then
            fruitTypeDesc = g_fruitTypeManager:getFruitTypeByIndex(spec.lastCuttersInputFruitType)
            if fruitTypeDesc~=nil then
                self.mrCombineLastValidFruitTypeDesc = fruitTypeDesc
            end
        end
        if fruitTypeDesc==nil then
            fruitTypeDesc = self.mrCombineLastValidFruitTypeDesc
        end
        if fruitTypeDesc~=nil then
            fruitCapacityFx = fruitTypeDesc.mrCapacityFx or 1
            fruitThreshingFx = fruitTypeDesc.mrThreshingFx or 1
            fruitChopperFx = fruitTypeDesc.mrChopperFx or 1
        end

        self.mrCombineLitersBuffer = self.mrCombineLitersBuffer + self.mrCombineLastLitersThreshed
        self.mrCombineLastLitersThreshed = 0
        --sample every 750 millisecond
        if g_time>self.mrCombineLitersBufferTime then
            local maxTime = 750
            local totalTime = maxTime + g_time - self.mrCombineLitersBufferTime
            self.mrCombineLitersPerSecond = 1000*self.mrCombineLitersBuffer / totalTime
            self.mrCombineLitersPerSecondS1 = 0.5*self.mrCombineLitersPerSecondS1 + 0.5*self.mrCombineLitersPerSecond --smooth1
            self.mrCombineLitersPerSecondS2 = 0.8*self.mrCombineLitersPerSecondS2 + 0.2*self.mrCombineLitersPerSecond --smooth2
            self.mrCombineLitersBuffer = 0
            self.mrCombineLitersBufferTime = g_time + maxTime
        end

        --threshingSystem
        neededPower = neededPower + self.mrCombineThreshingIdlePower
        if self.mrCombineLitersPerSecondS2>0.1 then
            neededPower = neededPower + self.mrCombineThreshingPowerFx * self.mrCombineLitersPerSecondS2 * 6 * fruitThreshingFx / RealisticMain.COMBINE_CAPACITY_FX
        end

        --chopper
        if spec.isSwathActive==false then
            neededPower = neededPower + self.mrCombineChopperIdlePower
            if self.mrCombineLitersPerSecondS2>0.1 then
                neededPower = neededPower + self.mrCombineChopperPowerFx * self.mrCombineLitersPerSecondS2 * 2.85 * fruitChopperFx / RealisticMain.COMBINE_CAPACITY_FX --about 1KW per ton per hour for wheat (fruitChopperFx==1). 1ton per hour for Wheat = 0.35 liters per second => factor 2.85 to get 1KW
            end
        end

        --update mrCombineSpeedLimit
        --conversion : tons per hour to liter per second
        local maxCapacity = self.mrCombineSpotRate*0.35*RealisticMain.COMBINE_CAPACITY_FX*fruitCapacityFx --Metric Ton per hour to Liters per second. Base "fruit" = wheat // 1000/0.79/3600 liters for wheat = 0.35


        local spd = self.lastSpeedReal*3600
        local peakWantedPower = 0.8*self.spec_powerConsumer.sourceMotorPeakPower
        local overloaded = false

        local minSpeedLimit = 3
        local maxSpeedLimit = self.mrCombineSpeedLimitMax
        local targetSpeedLimit = spd
        local targetSpeedLimitFx = 1

        --if both maxPower and maxCapacity are reached => decrease speed even faster
        if neededPower>peakWantedPower then --check needed power not too high
            targetSpeedLimitFx = math.sqrt(peakWantedPower/neededPower)
            overloaded = true
        end
        if self.mrCombineLitersPerSecondS1>1.04*maxCapacity then --check max capacity
            targetSpeedLimitFx = math.min(targetSpeedLimitFx, maxCapacity/self.mrCombineLitersPerSecondS1)
            overloaded = true
        end

        if overloaded then
            targetSpeedLimit = math.max(minSpeedLimit, spd * targetSpeedLimitFx)
        elseif self.mrCombineLitersPerSecondS2<0.96*maxCapacity then
            targetSpeedLimit = math.min(maxSpeedLimit, spd * maxCapacity/math.max(0.1, self.mrCombineLitersPerSecondS2))
        else
            targetSpeedLimit = math.clamp(targetSpeedLimit, minSpeedLimit, maxSpeedLimit)
        end

        --update last ton per hour rate
        if spec.lastCuttersOutputFillType~=nil and spec.lastCuttersOutputFillType~=FillType.UNKNOWN then
            local fillTypeDesc = g_fillTypeManager:getFillTypeByIndex(spec.lastCuttersOutputFillType)
            self.mrCombineLastTonsPerHour = fillTypeDesc.massPerLiter * self.mrCombineLitersPerSecondS2 * 3600
        end

        --update speedLimit
        if targetSpeedLimit==maxSpeedLimit and spd>maxSpeedLimit then
            self.mrCombineSpeedLimit = maxSpeedLimit
        elseif targetSpeedLimit==minSpeedLimit and spd<minSpeedLimit then
            self.mrCombineSpeedLimit = minSpeedLimit
        elseif targetSpeedLimit<spd then
            if self.mrCombineSpeedLimit<targetSpeedLimit then
                self.mrCombineSpeedLimit = targetSpeedLimit
            elseif self.mrCombineSpeedLimit>targetSpeedLimit then
                local speedFactor = (spd/maxSpeedLimit)^2
                local wantedSpeedFactor = (targetSpeedLimit-spd)/math.max(1, maxSpeedLimit-minSpeedLimit)
                self.mrCombineSpeedLimit = math.max(targetSpeedLimit, self.mrCombineSpeedLimit + 4*speedFactor*wantedSpeedFactor*g_physicsDtLastValidNonInterpolated/1000)
            end
        elseif targetSpeedLimit~=spd then
            local speedFactor = (spd/self.mrCombineSpeedLimitMax)^2
            local wantedSpeedFactor = (targetSpeedLimit-spd)/math.max(1, self.mrCombineSpeedLimitMax-minSpeedLimit)
            self.mrCombineSpeedLimit = self.mrCombineSpeedLimit + 4*speedFactor*wantedSpeedFactor*g_physicsDtLastValidNonInterpolated/1000
            self.mrCombineSpeedLimit = math.clamp(self.mrCombineSpeedLimit, minSpeedLimit, self.mrCombineSpeedLimitMax)
        end

    else
        self.mrCombineLitersPerSecond = 0
        self.mrCombineLitersPerSecondS1 = 0
        self.mrCombineLitersPerSecondS2 = 0
        self.mrCombineSpeedLimit = 999
        self.mrCombineLastValidFruitTypeDesc = nil
    end


    return neededPower

end


Combine.mrAddCutterArea = function(self, superFunc, area, liters, inputFruitType, outputFillType, strawRatio, farmId, cutterLoad)

    if self.mrIsMrCombine then
        --we want to store the number of liters threshed by "frame"
        self.mrCombineLastLitersThreshed = self.mrCombineLastLitersThreshed + liters
    end

    return superFunc(self, area, liters, inputFruitType, outputFillType, strawRatio, farmId, cutterLoad)

end
Combine.addCutterArea = Utils.overwrittenFunction(Combine.addCutterArea, Combine.mrAddCutterArea)

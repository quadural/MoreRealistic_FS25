-- base game : front weight configuration is not convenient. You have to "compute" (or adjust figures and check ingame multiple times)
-- Biggest problem = if you have to modify/adjust the center of mass or the mass of the base vehicle component, then, you have to modify all the objectChange configuration again
-- MR solution = instead of telling the game the new component mass and center of mass, you only give to it the additionnal mass wanted and the aditionnal mass "COM" (center of mass)

ObjectChangeUtil.mrRegisterObjectChangeSingleXMLPaths = function(schema, superFunc, basePath)
    superFunc(schema, basePath)
    schema:register(XMLValueType.FLOAT, basePath .. ".objectChange(?)#mrAddMassActive", "additional mass to the component if object change is active")
    schema:register(XMLValueType.FLOAT, basePath .. ".objectChange(?)#mrAddMassInactive", "additional mass to the component if object change is not active")
    schema:register(XMLValueType.VECTOR_3, basePath .. ".objectChange(?)#mrAddMassCOMActive", "additional mass 'center of mass' if object change is active")
    schema:register(XMLValueType.VECTOR_3, basePath .. ".objectChange(?)#mrAddMassCOMInactive", "additional mass 'center of mass' if object change is not active")
end

ObjectChangeUtil.registerObjectChangeSingleXMLPaths = Utils.overwrittenFunction(ObjectChangeUtil.registerObjectChangeSingleXMLPaths, ObjectChangeUtil.mrRegisterObjectChangeSingleXMLPaths)

ObjectChangeUtil.mrLoadValuesFromXML = function(xmlFile, superFunc, key, node, object, parent, rootNode, i3dMappings)
    superFunc(xmlFile, key, node, object, parent, rootNode, i3dMappings)

    object.mrAddMass = xmlFile:getString(key.."#mrAddMassActive")
    if object.mrAddMass~=nil then
        object.mrAddMass = object.mrAddMass / 1000
    end

    ObjectChangeUtil.loadValueType(object.values, xmlFile, key, "mrAddMassCOM",
        function()
            return getCenterOfMass(node)
        end,
        function(x, y, z)
            local newX, newY, newZ
            local x0, y0, z0 = getCenterOfMass(node)
            local baseMass = getMass(node)
            local addMass = object.mrAddMass
            newX = (baseMass*x0+addMass*x)/(baseMass+addMass)
            newY = (baseMass*y0+addMass*y)/(baseMass+addMass)
            newZ = (baseMass*z0+addMass*z)/(baseMass+addMass)

            setCenterOfMass(node, newX, newY, newZ)

            if parent ~= nil and parent.components ~= nil then
                for _, component in ipairs(parent.components) do
                    if component.node == object.node then
                        component.mrDefaultCOMx = newX
                        component.mrDefaultCOMy = newY
                        component.mrDefaultCOMz = newZ
                        parent:setMassDirty()
                    end
                end
            end

        end,
        true, nil, true)

    ObjectChangeUtil.loadValueType(object.values, xmlFile, key, "mrAddMass",
        function()
            return getMass(node)
        end,
        function(value)
            local baseMass = getMass(node)
            local newMass = baseMass + value / 1000
            setMass(node, newMass)

            if parent ~= nil and parent.components ~= nil then
                for _, component in ipairs(parent.components) do
                    if component.node == object.node then
                        component.defaultMass = newMass
                        parent:setMassDirty()
                    end
                end
            end
        end, true)

end
ObjectChangeUtil.loadValuesFromXML = Utils.overwrittenFunction(ObjectChangeUtil.loadValuesFromXML, ObjectChangeUtil.mrLoadValuesFromXML)
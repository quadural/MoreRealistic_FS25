Wheel.mrRegisterXMLPaths = function(schema, superFunc, key)
    superFunc(schema, key)
    --allow us to get the rim dimension in the WheelPhysics.mrLoadAdditionalWheel function
    schema:register(XMLValueType.VECTOR_2, key .. ".outerRim#widthAndDiam", "Rim dimension")
end
Wheel.registerXMLPaths = Utils.overwrittenFunction(Wheel.registerXMLPaths, Wheel.mrRegisterXMLPaths)
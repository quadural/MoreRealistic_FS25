RealisticMain = {}

RealisticMain.COMBINE_CAPACITY_FX = 1.25 --apply a 20% factor since this is a game to avoid getting too low max harvesting speed

--VehicleDebug.setState(VehicleDebug.DEBUG_PHYSICS)

local mrEngineModName = "MoreRealistic"
local mrEngineDirectory = g_modNameToDirectory[mrEngineModName]

--check the "moreRealistic" folder is present
if mrEngineDirectory==nil then
    print("[MoreRealistic] : ERROR, the moreRealistic mod folder must remains with the exact name = 'MoreRealistic'.")
end

-- Global Classes
--SpecializationManager.addSpecialization("realisticUtils", "RealisticUtils", mrEngineDirectory .. "/scripts/RealisticUtils.lua")

-- load "moreRealistic" figures for tire friction vs surface and rooling resistance
MoreRealistic.RealisticUtils.loadRealTyresFrictionAndRr(g_currentModDirectory .. "data/TyresFrictionAndRrTable.xml")


-- load modified data for default vehicles
MoreRealistic.RealisticUtils.loadDefaultVehiclesModifiedData(g_currentModDirectory .. "data/overriding", "overridingDatabase.xml")

MoreRealistic.RealisticUtils.mrBaseDir = g_currentModDirectory


function RealisticMain:loadMap(name)

    RealisticUtils.loadTerrainIdToName()

end

addModEventListener(RealisticMain)
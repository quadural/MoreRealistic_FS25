WoodCrusher.mrLoadWoodCrusher = function(self, superFunc, woodCrusher, xmlFile, rootNode, i3dMappings)
    superFunc(self, woodCrusher, xmlFile, rootNode, i3dMappings)

    --old way of loading xml values to be able to read the MR xml file instead of the genuine vehicle one
    local xmlFileMR = loadXMLFile("Vehicle", self.xmlFile.filename)
    woodCrusher.mrWoodCrusherPowerFx = getXMLFloat(xmlFileMR, "vehicle.mrWoodCrusher#powerFx") or 1
    woodCrusher.mrIdlePower = getXMLFloat(xmlFileMR, "vehicle.mrWoodCrusher#idlePower") or 15
    woodCrusher.mrMaxCrushingPowerPossible = getXMLFloat(xmlFileMR, "vehicle.mrWoodCrusher#maxCrushingPower")
    woodCrusher.mrMaxTractionForce = getXMLFloat(xmlFileMR, "vehicle.mrWoodCrusher#maxTractionForce") or 10
    woodCrusher.mrCutWidth = getXMLFloat(xmlFileMR, "vehicle.mrWoodCrusher#cutFeedWidth")
    delete(xmlFileMR)

    if woodCrusher.mrCutWidth==nil then
        woodCrusher.mrCutWidth = 0.8*woodCrusher.cutSizeZ
    end

    self.mrWoodCrusherPowerConsumption = 0
    woodCrusher.mrFeedingActive = false
    woodCrusher.mrFeedingLastStateActive = false
    woodCrusher.mrFeedingAnimationRunning = false
    woodCrusher.mrCrushingPowerWanted = 0
    woodCrusher.mrWaitingForFillLevel = false

    --no loss MR25 system
    woodCrusher.mrCheckSplitShapes = {}
    woodCrusher.mrCheckSplitShapes.shapes = nil
    woodCrusher.mrCheckSplitShapes.genuineVolume = 0
    woodCrusher.mrCheckSplitShapes.splitTypeIndex = 0

    if woodCrusher.mrMaxCrushingPowerPossible==nil then
        --maxCrushingPower the woodcrusher can handle => above that, the feeding system will pause even if the tractor's engine has still power available
        local neededMaxPtoPower = xmlFile:getValue("vehicle.powerConsumer#neededMaxPtoPower")
        if neededMaxPtoPower~=nil then
            woodCrusher.mrMaxCrushingPowerPossible = 2*neededMaxPtoPower
        else
            woodCrusher.mrMaxCrushingPowerPossible = 350 --default value when nothing is found
        end
    end

end
WoodCrusher.loadWoodCrusher = Utils.overwrittenFunction(WoodCrusher.loadWoodCrusher, WoodCrusher.mrLoadWoodCrusher)

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--
--MR : we want a varying power requirement for the wood crusher depending on the "actual crushing load"
--     we want varying crushing time
--
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
WoodCrusher.mrCrushSplitShape = function(self, superFunc, woodCrusher, shape)
    local splitType = g_splitShapeManager:getSplitTypeByIndex(getSplitType(shape))
    if splitType ~= nil and splitType.woodChipsPerLiter > 0 then
        local volume = getVolume(shape)
        delete(shape)
        WoodCrusher.mrProcessVolume(self, woodCrusher, splitType, volume)
    end
end
WoodCrusher.crushSplitShape = Utils.overwrittenFunction(WoodCrusher.crushSplitShape, WoodCrusher.mrCrushSplitShape)

WoodCrusher.mrProcessVolume = function(self, woodCrusher, splitType, volume)
    if splitType ~= nil and splitType.woodChipsPerLiter > 0 then
        local crushNeededTime = math.clamp(100000*volume, 700, 3000) --MR : varying crushing time
        woodCrusher.crushingTime = math.max(woodCrusher.crushingTime, crushNeededTime)
        self:onCrushedSplitShape(splitType, volume)
        local powerRequired = 4 * woodCrusher.mrWoodCrusherPowerFx * volume * splitType.volumeToLiter * splitType.woodChipsPerLiter --this takes into account the wood essence => the more woodChips produced, the more power consumed
        --20250622 - limit to 2x mrMaxCrushingPowerPossible because sometimes, a big piece of wood is crush in one time (usually = very high, very wide, but not thick)
        powerRequired = math.min(2*woodCrusher.mrMaxCrushingPowerPossible, powerRequired)
        woodCrusher.mrCrushingPowerWanted = woodCrusher.mrCrushingPowerWanted + powerRequired
    end
end

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--
--MR : we want to limit crushing speed according to engine capability (base game = you can put the smallest engine matching the min power required and get the same result as a big one) = no point in putting a bigger tractor
--MR = the more power we have, the faster we can make woodchip
--
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
WoodCrusher.mrUpdateTickWoodCrusher = function(self, superFunc, woodCrusher, dt, isTurnedOn)

    if self.isServer then
        if isTurnedOn then
            if not woodCrusher.mrFeedingActive then
                if woodCrusher.mrFeedingLastStateActive then
                    if woodCrusher.moveColNodes ~= nil then
                        for _, moveColNode in pairs(woodCrusher.moveColNodes) do
                            setFrictionVelocity(moveColNode.node, 0.0)
                        end
                    end
                end
                woodCrusher.mrFeedingLastStateActive = false
            else
                if not woodCrusher.mrFeedingLastStateActive then
                    if woodCrusher.moveColNodes ~= nil then
                        for _, moveColNode in pairs(woodCrusher.moveColNodes) do
                            setFrictionVelocity(moveColNode.node, woodCrusher.moveVelocityZ)
                        end
                    end
                end
                woodCrusher.mrFeedingLastStateActive = true

                if woodCrusher.cutNode ~= nil and next(woodCrusher.moveTriggerNodes) ~= nil then
                    local x,y,z = getWorldTranslation(woodCrusher.cutNode)
                    local nx,ny,nz = localDirectionToWorld(woodCrusher.cutNode, 1,0,0)
                    local yx,yy,yz = localDirectionToWorld(woodCrusher.cutNode, 0,1,0)
                    local maxAvailableForce = woodCrusher.mrMaxTractionForce
                    if #woodCrusher.moveTriggerNodes>1 then
                        maxAvailableForce = maxAvailableForce / #woodCrusher.moveTriggerNodes
                    end
                    for id in pairs(woodCrusher.moveTriggerNodes) do
                        if entityExists(id) then
                            --lenAbove = part we want to crush
                            --lenBelow = remaining part
                            local lenBelow, lenAbove = getSplitShapePlaneExtents(id, x,y,z, nx,ny,nz)
                            if lenAbove ~= nil and lenBelow ~= nil then
                                local totalLen = lenAbove + lenBelow
                                if totalLen <= 0.4 then --if remaining log is too small, crush the whole remaining log
                                    woodCrusher.moveTriggerNodes[id] = nil
                                    WoodCrusher.crushSplitShape(self, woodCrusher, id)
                                elseif lenAbove >= 0.2 then
                                    self.shapeBeingCut = id
                                    --debug

                                    --whether or not the split occurs, the "id" shape is not valid after the call to this function
                                    --problem : when using splitShape, if one part after the cut is too small, it is not created = lost wood
                                    --we can experience that with the chainsaw too = cutting "cookies" means they disappear after the cut is complete

                                    --1. store the current volume and reset the checkSlipShapes data
                                    woodCrusher.mrCheckSplitShapes.shapes = {}
                                    woodCrusher.mrCheckSplitShapes.genuineVolume = getVolume(id)
                                    woodCrusher.mrCheckSplitShapes.splitTypeIndex = getSplitType(id)

                                    --2. split the log (the splitshape can split in more than 2 parts)
                                    local minY = splitShape(id, x,y,z, nx,ny,nz, yx,yy,yz, woodCrusher.cutSizeY, woodCrusher.cutSizeZ, "woodCrusherSplitShapeCallback", woodCrusher)
                                    g_treePlantManager:removingSplitShape(id)

                                    --3. in the update function, before processing the "crushNodes", check if there is a lost volume from a cut

                                    if minY ~= nil then --minY ~=nil means the tree has been split in 2 or more, and so, the current tree id is not valid anymore (2 new entities created at split time)
                                        woodCrusher.moveTriggerNodes[id] = nil
                                    end
                                else
                                    --MR : there is a log (enough long not to be crushed in one time) under the feeding roller, but the part in the crusher is too small to be split
                                    --we really want the log to move toward the crusher, especially knowing it is under the feeding roller which should exerce a very high moving force on it
                                    --the force should be downward because of the feeding roller and toward the crusher => 2 forces or one force "diagonal" ?

                                    local mass = getMass(id)
                                    if mass~=nil then

                                        --check the current velocity
                                        local vx,vy,vz = getLinearVelocity(id)
                                        local lvx,_,_ = worldDirectionToLocal(woodCrusher.cutNode, vx,vy,vz) -- woodCrusherCutNode has always its x direction toward the cutter
                                        if lvx < woodCrusher.moveVelocityZ then --not enough speed

                                            --1. we have to define where to apply the force to the log
                                            local offset = math.min(1.25, math.max(0, -lenAbove)) --traction force -> max 1.25m away from cutnode
                                            local lx,ly,lz = localToWorld(woodCrusher.cutNode, -offset, 0, 0) --testing 25cm before reaching the cutting node
                                            local minY,maxY,minZ,maxZ = testSplitShape(id, lx,ly,lz, nx,ny,nz, yx,yy,yz, woodCrusher.cutSizeY, woodCrusher.cutSizeZ) --results are local pos : minY and maxY = pos compared to ly // minZ and maxZ = pos compared to lz
                                            if minY ~= nil then
                                                local cx,cy,cz = localToWorld(woodCrusher.cutNode, 0, minY, 0.5*(minZ+maxZ)) --this is the world point where to apply the force to the log
                                                --2. we apply a force from this point to the traction node position
                                                --local tx, ty, tz = localToWorld(woodCrusher.cutNode, 0, 0, (0.3+0.4*math.random())*woodCrusher.mrCutWidth)
                                                local tx, ty, tz = localDirectionToWorld(woodCrusher.cutNode, 1, -1, 0.5*woodCrusher.mrCutWidth-0.5*(minZ+maxZ)) --a little toward the "ground", and trying to target the center of the cutting roller
                                                local force = math.min(mass*9, maxAvailableForce) --1 * 9.81 * mass = limit to less than 100% of the weight to avoid "IFO" (identified flying objects)
                                                --3. limit force according to current velocity of the log
                                                if woodCrusher.moveVelocityZ>0 then
                                                    force = force * math.min(1, math.abs((woodCrusher.moveVelocityZ-lvx)/woodCrusher.moveVelocityZ))
                                                end

                                                addForce(id, force*tx, force*ty, force*tz, cx,cy,cz, false)

                                                if (VehicleDebug.state == VehicleDebug.DEBUG_PHYSICS or VehicleDebug.state == VehicleDebug.DEBUG_TUNING) and self.isActiveForInputIgnoreSelectionIgnoreAI then
                                                    --display the applied force
                                                    --drawDebugLine(tx, ty, tz, 1,0,0, cx, cy, cz, 1,0,1)
                                                    DebugGizmo.renderAtPosition(cx, cy, cz, tx, ty, tz, 0, 1, 0, "Traction Force", false, 2)
                                                end

                                            end
                                        end
                                    end

                                end
                            end
                        else
                            woodCrusher.moveTriggerNodes[id] = nil
                        end
                    end
                end

                if woodCrusher.moveColNodes ~= nil then
                    for _, moveColNode in pairs(woodCrusher.moveColNodes) do
                        setTranslation(moveColNode.node, moveColNode.transX, moveColNode.transY + math.random() * 0.005, moveColNode.transZ)
                    end
                end
            end
         end
    end

    if woodCrusher.crushingTime > 0 then
        woodCrusher.crushingTime = math.max(woodCrusher.crushingTime - dt, 0)
    end

    local isCrushing = woodCrusher.crushingTime > 0

    if self.isClient then
        if isCrushing then
            g_effectManager:setEffectTypeInfo(woodCrusher.crushEffects, FillType.WOODCHIPS)
            g_effectManager:startEffects(woodCrusher.crushEffects)
        else
            g_effectManager:stopEffects(woodCrusher.crushEffects)
        end

        if isTurnedOn and isCrushing then
            if not woodCrusher.isWorkSamplePlaying then
                g_soundManager:playSample(woodCrusher.samples.work)
                woodCrusher.isWorkSamplePlaying = true
            end
        else
            if woodCrusher.isWorkSamplePlaying then
                g_soundManager:stopSample(woodCrusher.samples.work)
                woodCrusher.isWorkSamplePlaying = false
            end
        end

        if isTurnedOn and woodCrusher.mrFeedingActive then
            if not woodCrusher.mrFeedingAnimationRunning then
                g_animationManager:startAnimations(woodCrusher.animationNodes)
                woodCrusher.mrFeedingAnimationRunning = true
            end
        elseif woodCrusher.mrFeedingAnimationRunning then
            g_animationManager:stopAnimations(woodCrusher.animationNodes)
            woodCrusher.mrFeedingAnimationRunning = false
        end

    end

end
WoodCrusher.updateTickWoodCrusher = Utils.overwrittenFunction(WoodCrusher.updateTickWoodCrusher, WoodCrusher.mrUpdateTickWoodCrusher)


---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--
--MR : we want to update power consumption
--we stop feeding system in 3 cases :
--     * rpm too low
--     * output pipe overloaded
--     * wanted crushing power too high
--
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
WoodCrusher.mrUpdateWoodCrusher = function(self, superFunc, woodCrusher, dt, isTurnedOn)

    if self.isServer then
        if not isTurnedOn then
            --reset power needed
            woodCrusher.mrCrushingPowerWanted = 0
            self.mrWoodCrusherPowerConsumption = 0 --this is the power read by the powerConsumer class
        else

            --before processing the "crushNodes", check if there is a lost volume from the previous cut
            if  woodCrusher.mrCheckSplitShapes.genuineVolume > 0.001 then --volume is in m3
                local shapesVolume = 0
                for shape in pairs(woodCrusher.mrCheckSplitShapes.shapes) do
                    shapesVolume = shapesVolume + getVolume(shape)
                end
                local lostVolume = woodCrusher.mrCheckSplitShapes.genuineVolume - shapesVolume
                if lostVolume>0 then
                    local splitType = g_splitShapeManager:getSplitTypeByIndex(woodCrusher.mrCheckSplitShapes.splitTypeIndex)
                    WoodCrusher.mrProcessVolume(self, woodCrusher, splitType, lostVolume)
                end

                --reset mrCheckSplitShapes data
                woodCrusher.mrCheckSplitShapes.shapes = nil
                woodCrusher.mrCheckSplitShapes.genuineVolume = 0
                woodCrusher.mrCheckSplitShapes.splitTypeIndex = 0
            end

            --if there are woodShapes to crush = crush them
            for node in pairs(woodCrusher.crushNodes) do
                WoodCrusher.crushSplitShape(self, woodCrusher, node)
                woodCrusher.crushNodes[node] = nil
                woodCrusher.moveTriggerNodes[node] = nil
            end


            --check if we stop feeding system or not
            --MR = we don't want to move the feeding roller/pickup when the pto speed is too slow
            woodCrusher.mrFeedingActive = true
            if self.mrPtoCurrentRpmRatio~=nil then
                if self.mrPtoCurrentRpmRatio<0.78 then
                    woodCrusher.mrFeedingActive = false
                else
                    woodCrusher.mrFeedingActive = true
                end
            end

            local maxCrushingPowerWanted = woodCrusher.mrMaxCrushingPowerPossible
            if self.getMotor~=nil then
                local rootMotor = self:getMotor()
                maxCrushingPowerWanted = math.min(maxCrushingPowerWanted, rootMotor.peakMotorPower)
            else
                local rootAttacherVehicle = self:getRootVehicle()
                if rootAttacherVehicle ~= nil and rootAttacherVehicle.getMotor ~= nil then
                    local rootMotor = rootAttacherVehicle:getMotor()
                    maxCrushingPowerWanted = math.min(maxCrushingPowerWanted, rootMotor.peakMotorPower)
                end
            end

            --update power consumption
            woodCrusher.mrCrushingPowerWanted = math.max(woodCrusher.mrIdlePower, woodCrusher.mrCrushingPowerWanted - maxCrushingPowerWanted*dt/1000)
            self.mrWoodCrusherPowerConsumption = (1-0.005*dt)*self.mrWoodCrusherPowerConsumption + (0.005*dt)*woodCrusher.mrCrushingPowerWanted

            if woodCrusher.mrCrushingPowerWanted>maxCrushingPowerWanted then
                woodCrusher.mrFeedingActive = false
            end

            --MR : check fillLevel of the temp tank
            local currentfillLevelRatio = self:getFillUnitFillLevelPercentage(self.spec_woodCrusher.fillUnitIndex)
            if currentfillLevelRatio>0.5 then
                --crushing process is too fast for the machine = pause the feeding system
                woodCrusher.mrWaitingForFillLevel = true
            elseif currentfillLevelRatio<0.1 then
                --hysteresis : unpause the feeding system when the machine is no more overloaded
                woodCrusher.mrWaitingForFillLevel = false
            end

            if woodCrusher.mrWaitingForFillLevel then
                woodCrusher.mrFeedingActive = false
            end

            --MR : we don't want to apply forces or move the feeding roller when it is actually stopped
            if woodCrusher.mrFeedingActive then

                local maxTreeSizeY = 0
                for id in pairs(woodCrusher.moveTriggerNodes) do
                    if not entityExists(id) then
                        woodCrusher.moveTriggerNodes[id] = nil
                    else
                        for i=1, #woodCrusher.downForceNodes do
                            local downForceNode = woodCrusher.downForceNodes[i]
                            if downForceNode.triggerNodes[id] ~= nil or downForceNode.trigger == nil then
                                local x, y, z = getWorldTranslation(downForceNode.node)
                                local nx, ny, nz = localDirectionToWorld(downForceNode.node, 1,0,0)
                                local yx, yy, yz = localDirectionToWorld(downForceNode.node, 0,1,0)

                                local minY,maxY, minZ,maxZ = testSplitShape(id, x,y,z, nx,ny,nz, yx,yy,yz, downForceNode.sizeY, downForceNode.sizeZ)
                                if minY ~= nil then
                                    local cx,cy,cz = localToWorld(downForceNode.node, 0, (minY+maxY)*0.5, (minZ+maxZ)*0.5)
                                    --MR : limit downforce according to log mass => avoid getting small branches flying all over the place
                                    local logMass = getMass(id)
                                    local downForce = math.min(downForceNode.force, logMass*9.81)
                                    local downX,downY,downZ = localDirectionToWorld(downForceNode.node, 0, -downForce, 0)
                                    addForce(id, downX, downY, downZ, cx,cy,cz, false)
                                    --#debug drawDebugLine(cx, cy, cz, 1, 0, 0, cx+downX, cy+downY, cz+downZ, 0, 1, 0, true)
                                end
                            end
                        end

                        if woodCrusher.shapeSizeDetectionNode ~= nil then
                            local x, y, z = getWorldTranslation(woodCrusher.shapeSizeDetectionNode)
                            local nx, ny, nz = localDirectionToWorld(woodCrusher.shapeSizeDetectionNode, 1,0,0)
                            local yx, yy, yz = localDirectionToWorld(woodCrusher.shapeSizeDetectionNode, 0,1,0)

                            local minY, maxY, _, _ = testSplitShape(id, x, y, z, nx, ny, nz, yx, yy, yz, woodCrusher.cutSizeY, woodCrusher.cutSizeZ)
                            if minY ~= nil then
                                if woodCrusher.mainDrumRefNode ~= nil then
                                    maxTreeSizeY = math.max(maxTreeSizeY, maxY)
                                end
                            end
                        end
                    end
                end
                if woodCrusher.mainDrumRefNode ~= nil then
                    local x, y, z = getTranslation(woodCrusher.mainDrumRefNode)
                    local ty = math.min(maxTreeSizeY, woodCrusher.mainDrumRefNodeMaxY)
                    if ty > y then
                        y = math.min(y + 0.0003*dt, ty)
                    else
                        y = math.max(y - 0.0003*dt, ty)
                    end

                    setTranslation(woodCrusher.mainDrumRefNode, x, y, z)
                end

            end --end MR mrFeedingActive

            if next(woodCrusher.moveTriggerNodes) ~= nil or woodCrusher.crushingTime > 0 then
                self:raiseActive()
            end
        end
    end
end
WoodCrusher.updateWoodCrusher = Utils.overwrittenFunction(WoodCrusher.updateWoodCrusher, WoodCrusher.mrUpdateWoodCrusher)



---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--
--MR : we want to know if split shape get 2 new shapes, or split nothing, or get only one new shape and nothing
-- if the split worked, this function is called 2 times
-- isBelow = part after the cut (remaining part)
-- isAbove = part before the cut (what we want to crush)
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
WoodCrusher.mrWoodCrusherSplitShapeCallback = function(self, superFunc, shape, isBelow, isAbove, minY, maxY, minZ, maxZ)

    --the new shape is not ready yet, we can't call the getVolume function on it
    if shape~=nil then
        self.spec_woodCrusher.mrCheckSplitShapes.shapes[shape] = shape
    end

    if isAbove then
        self.crushNodes[shape] = shape
        g_treePlantManager:addingSplitShape(shape, self.shapeBeingCut)
    end

end
WoodCrusher.woodCrusherSplitShapeCallback = Utils.overwrittenFunction(WoodCrusher.woodCrusherSplitShapeCallback, WoodCrusher.mrWoodCrusherSplitShapeCallback)


---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--
--MR : we want to be able to stop feeding animation even if the crusher is working
--
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
WoodCrusher.onReadUpdateStream = function(self, streamId, timestamp, connection)
    if connection:getIsServer() then
        local spec = self.spec_woodCrusher
        if streamReadBool(streamId) then
            spec.crushingTime = 1000
        else
            spec.crushingTime = 0
        end
        spec.mrFeedingActive = streamReadBool(streamId)
    end
end


WoodCrusher.onWriteUpdateStream = function(self, streamId, connection, dirtyMask)
    if not connection:getIsServer() then
        local spec = self.spec_woodCrusher
        streamWriteBool(streamId, spec.crushingTime > 0)
        streamWriteBool(streamId, spec.mrFeedingActive)
    end
end



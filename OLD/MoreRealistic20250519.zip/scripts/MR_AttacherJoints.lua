--new convenient feature : handle lowering one tool when tractor is selected and a front weight is attached and an implement is on the back (only useful in debug mode ?)
AttacherJoints.mrOnRegisterActionEvents = function(self, superFunc, isActiveForInput, isActiveForInputIgnoreSelection)
    if self.isClient then
        local spec = self.spec_attacherJoints
        self:clearActionEventsTable(spec.actionEvents)

        -- ignore vehicle selection on 'getIsActiveForInput', so we can select the target vehicle and attach or lower it
        if isActiveForInputIgnoreSelection then
            if #spec.attacherJoints > 0 then
                -- only display lower and attach action if selected implement is direct child of vehicle, not sub child
                local selectedImplement = self:getSelectedImplement()
                if selectedImplement ~= nil and selectedImplement.object ~= self then
                    for _, attachedImplement in pairs(spec.attachedImplements) do
                        if attachedImplement == selectedImplement then
                            -- custom registration of the action event. This allows us to overwritte it in the implement (e.g in Foldable)
                            selectedImplement.object:registerLoweringActionEvent(spec.actionEvents, InputAction.LOWER_IMPLEMENT, selectedImplement.object, AttacherJoints.actionEventLowerImplement, false, true, false, true, nil, nil, true)
                        end
                    end
                end

                local _, actionEventId = self:addPoweredActionEvent(spec.actionEvents, InputAction.LOWER_ALL_IMPLEMENTS, self, AttacherJoints.actionEventLowerAllImplements, false, true, false, true, nil, nil, true)
                g_inputBinding:setActionEventTextVisibility(actionEventId, false)
            end

            if self:getSelectedVehicle() == self then
                local state, _ = self:registerSelfLoweringActionEvent(spec.actionEvents, InputAction.LOWER_IMPLEMENT, self, AttacherJoints.actionEventLowerImplement, false, true, false, true, nil, nil, true)

                -- if the selected attacher vehicle can not be lowered and we got only one implement that can be lowered
                -- we add the lowering action for the first implement
                if state == nil or not state then
                    if #spec.attachedImplements == 1 then
                        local firstImplement = spec.attachedImplements[1]
                        if firstImplement ~= nil then
                            firstImplement.object:registerLoweringActionEvent(spec.actionEvents, InputAction.LOWER_IMPLEMENT, firstImplement.object, AttacherJoints.actionEventLowerImplement, false, true, false, true, nil, nil, true)
                        end
                    elseif #spec.attachedImplements == 2 then
                        local implement1 = spec.attachedImplements[1]
                        local implement2 = spec.attachedImplements[2]
                        if implement1~=nil and (implement2==nil or implement2.object.mrStoreCategory=="weights") then
                            implement1.object:registerLoweringActionEvent(spec.actionEvents, InputAction.LOWER_IMPLEMENT, implement1.object, AttacherJoints.actionEventLowerImplement, false, true, false, true, nil, nil, true)
                        elseif implement2~=nil and (implement1==nil or implement1.object.mrStoreCategory=="weights") then
                            implement2.object:registerLoweringActionEvent(spec.actionEvents, InputAction.LOWER_IMPLEMENT, implement2.object, AttacherJoints.actionEventLowerImplement, false, true, false, true, nil, nil, true)
                        end
                    end
                end
            end

            local _, actionEventId = self:addActionEvent(spec.actionEvents, InputAction.ATTACH, self, AttacherJoints.actionEventAttach, false, true, false, true, nil, nil, true)
            g_inputBinding:setActionEventTextPriority(actionEventId, GS_PRIO_VERY_HIGH)

            _, actionEventId = self:addActionEvent(spec.actionEvents, InputAction.DETACH, self, AttacherJoints.actionEventDetach, false, true, false, true, nil, nil, true)
            g_inputBinding:setActionEventTextVisibility(actionEventId, false)

            AttacherJoints.updateActionEvents(self)
        end
    end
end
AttacherJoints.onRegisterActionEvents = Utils.overwrittenFunction(AttacherJoints.onRegisterActionEvents, AttacherJoints.mrOnRegisterActionEvents)

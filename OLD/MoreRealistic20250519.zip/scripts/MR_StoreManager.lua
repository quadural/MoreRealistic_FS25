StoreManager.mrLoadItem = function(self, superFunc, rawXMLFilename, baseDir, customEnvironment, isMod, isBundleItem, dlcTitle, extraContentId, ignoreAdd)

    if baseDir=="" then
        local mrConfigFileName = MoreRealistic.RealisticUtils.getOverridingXmlFileName(rawXMLFilename)
        if mrConfigFileName~=nil then
            rawXMLFilename = mrConfigFileName
        end
    end

    local storeItem = superFunc(self, rawXMLFilename, baseDir, customEnvironment, isMod, isBundleItem, dlcTitle, extraContentId, ignoreAdd)

    if storeItem~=nil then
        --check if MR tag is present
        local xmlFilename = Utils.getFilename(rawXMLFilename, baseDir)
        local xmlFile = loadXMLFile("storeItemXML", xmlFilename)
        local isMrVehicle = getXMLBool(xmlFile, "vehicle.MR") or false
        delete(xmlFile)
        if isMrVehicle then
            storeItem.name = "MR " .. storeItem.name
        end
    end

    return storeItem
end
StoreManager.loadItem = Utils.overwrittenFunction(StoreManager.loadItem, StoreManager.mrLoadItem)


StoreManager.mrAddPackItem = function(self, superFunc, name, itemFilename)
    local mrConfigFileName = MoreRealistic.RealisticUtils.getOverridingXmlFileName(itemFilename)
    if mrConfigFileName~=nil then
        itemFilename = mrConfigFileName
    end

    return superFunc(self, name, itemFilename)
end
StoreManager.addPackItem = Utils.overwrittenFunction(StoreManager.addPackItem, StoreManager.mrAddPackItem)

StoreManager.mrGetItemByXMLFilename = function(self, superFunc, xmlFilename)
    if xmlFilename ~= nil then
        --check if MR version is present
        local mrConfigFileName = MoreRealistic.RealisticUtils.getOverridingXmlFileName(xmlFilename)
        if mrConfigFileName~=nil then
            return self.xmlFilenameToItem[mrConfigFileName:lower()]
        else
            return superFunc(self, xmlFilename)
        end
    end

    return nil
end
StoreManager.getItemByXMLFilename = Utils.overwrittenFunction(StoreManager.getItemByXMLFilename, StoreManager.mrGetItemByXMLFilename)
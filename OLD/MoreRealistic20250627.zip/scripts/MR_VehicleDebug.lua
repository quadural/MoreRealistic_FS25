VehicleDebug.mrDrawBaseDebugRendering = function(self, superFunc, x, y)
    local ret = superFunc(self, x, y)

    if self.spec_motorized then

        if not VehicleDebug.mrDebugChronoInitialized then
            VehicleDebug.mrDebugChrono1State=0
            VehicleDebug.mrDebugChrono2State=1
            VehicleDebug.mrDebugChrono1Time=0
            VehicleDebug.mrDebugChrono2Time=0
            VehicleDebug.mrDebugChrono1Timer=0
            VehicleDebug.mrDebugChrono2Timer=0
            VehicleDebug.mrDebugChronoInitialized = true
        end

        if self.spec_drivable.axisForward == 1 then
            VehicleDebug.mrDebugChrono1State = 1
            VehicleDebug.mrDebugChrono1Time = 0
            if VehicleDebug.mrDebugChrono2State==1 then
                VehicleDebug.mrDebugChrono2State=2
                VehicleDebug.mrDebugChrono2Time = 0
                VehicleDebug.mrDebugChrono2Timer = g_time
            end
            VehicleDebug.mrDebugChrono2Time = g_time - VehicleDebug.mrDebugChrono2Timer
        elseif VehicleDebug.mrDebugChrono2State==2 then
            VehicleDebug.mrDebugChrono2State=0
        end
        --display time and distance when acc is released and we reach 0 speed (braking time or engine brakingtime)
        if self.spec_drivable.axisForward==0 then
            VehicleDebug.mrDebugChrono2State = 1
            if VehicleDebug.mrDebugChrono1State==1 then
                --start counting
                VehicleDebug.mrDebugChrono1State = 2
                VehicleDebug.mrDebugChrono1Timer = g_time
            end
        end

        if VehicleDebug.mrDebugChrono1State==2 then
            VehicleDebug.mrDebugChrono1Time = g_time - VehicleDebug.mrDebugChrono1Timer
        end

        if self.lastSpeedReal<0.0001 then
            VehicleDebug.mrDebugChrono1State=0
            VehicleDebug.mrDebugChrono2State=1
        end

        --display time and distance after acc is fully depressed and then released
        local str1 = "Braking time:\n"
        local str2 = string.format("%1.2fs\n", (VehicleDebug.mrDebugChrono1Time or 0)/1000)

        str1 = str1.."Acc time:\n"
        str2 = str2..string.format("%1.2fs\n", (VehicleDebug.mrDebugChrono2Time or 0)/1000)

        local textSize = getCorrectTextSize(0.02)
        Utils.renderMultiColumnText(0.65, 0.70, textSize, {str1,str2}, 0.008, {RenderText.ALIGN_RIGHT,RenderText.ALIGN_LEFT})


        --20250603 - display acc pedal / brake pedal
        --20241230 - display slip smoothed (vanilla slip is illegible, change too often)
        --20241230 - display dynamic mass on the wheels

        local totalDynamicMass = 0
        local totalWheelsSpeed = 0
        local nbWheels = 0
        if self.spec_wheels ~= nil then
            for i, wheel in ipairs(self.spec_wheels.wheels) do
                totalDynamicMass = totalDynamicMass + wheel.physics.mrLastTireLoad/9.81 --KN to metric tons
                totalWheelsSpeed = totalWheelsSpeed + wheel.physics.mrLastWheelSpeed --m/s
                nbWheels = nbWheels + 1
            end
        end

        local slip = 0
        local lastSpeedReal = self.lastSpeedReal * 1000 --m/s
        if nbWheels>0 and lastSpeedReal > 0.01 then
            slip = (math.abs(totalWheelsSpeed)/nbWheels)/lastSpeedReal - 1
        end
        self.mrSlipSmoothed = self.mrSlipSmoothed==nil and 0 or (0.99*self.mrSlipSmoothed + slip) --0.01*slip*100

        local str3 = "Acc pedal:\nBrake pedal:\nEngine braking:\nSlipS:\nDyn Mass:\n"

        local accPedal = self.wheelsUtilSmoothedAcceleratorPedal or 0
        local brakePedal = self.wheelsUtilSmoothedBrakePedal or 0

        local str4 = string.format("%1.2f\n", accPedal) .. string.format("%1.2f\n", brakePedal) ..string.format("%s\n",self.spec_motorized.mrLastEngineIsBraking) .. string.format("%1.1f%%\n", self.mrSlipSmoothed) .. string.format("%1.1fT\n", totalDynamicMass)
        Utils.renderMultiColumnText(0.17, 0.574, textSize, {str3,str4}, 0.008, {RenderText.ALIGN_RIGHT,RenderText.ALIGN_LEFT})

        --20250222 - display fuel liter per hour smoothed
        self.spec_motorized.mrLastFuelUsageS = 0.99*self.spec_motorized.mrLastFuelUsageS + 0.01*self.spec_motorized.lastFuelUsage
        setTextAlignment(RenderText.ALIGN_LEFT)
        renderText(0.45, 0.562, textSize, string.format("%1.1f",self.spec_motorized.mrLastFuelUsageS))

        --20250318 - display "true" engine object current rotation speed
        setTextAlignment(RenderText.ALIGN_LEFT)
        renderText(0.45, 0.6, textSize, string.format("%1.0f", self.spec_motorized.motor.mrLastMotorObjectRotSpeed*9.5493))

        --20250331 - display combine auto speed limit
        if self.mrIsMrCombine then
            setTextAlignment(RenderText.ALIGN_LEFT)
            renderText(0.8, 0.5, textSize, string.format("Spd=%1.2f", self.mrCombineSpeedLimit))
            renderText(0.8, 0.52, textSize, string.format("T/h=%1.2f", self.mrCombineLastTonsPerHour))
        end

    end

    if self.spec_woodCrusher then
        --20250619 - display woodcrusher power consumption
        if self.mrWoodCrusherPowerConsumption~=nil then
            local textSize = getCorrectTextSize(0.02)
            setTextAlignment(RenderText.ALIGN_LEFT)
            renderText(0.8, 0.7, textSize, string.format("WoodCrusher KW=%1.2f", self.mrWoodCrusherPowerConsumption))
        end
    end

    return ret

end
VehicleDebug.drawBaseDebugRendering = Utils.overwrittenFunction(VehicleDebug.drawBaseDebugRendering, VehicleDebug.mrDrawBaseDebugRendering)
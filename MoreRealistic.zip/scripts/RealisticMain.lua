local mrEngineModName = "MoreRealistic"
local mrEngineDirectory = g_modNameToDirectory[mrEngineModName]

--check the "moreRealistic" folder is present
if mrEngineDirectory==nil then
    Logging.error("[MoreRealistic] : ERROR, the moreRealistic mod folder must remains with the exact name = 'MoreRealistic'")
    return
end

RealisticMain = {}

RealisticMain.COMBINE_CAPACITY_FX = 1.15 --apply a 15% factor since this is a game to avoid getting too low max harvesting speed

--see MR_Motorized, "self.spec_motorized.motor.mrEngineBrakingPowerFx"
RealisticMain.ENGINE_BRAKING_FX_DEFAULT = 0.85 -- default factor applied to engine braking power
RealisticMain.ENGINE_BRAKING_FX_HYDROSTATIC = 1.5 -- default factor applied to engine braking power when the transmission is hydrostatic

RealisticMain.SPRAYER_EMPTYSPEED_FX = 1.5 --default factor applied to dischargeNode#emptySpeed for sprayer

RealisticMain.BALE_GRASS_MASS_FX = 0.6 -- in game, there is no difference between "forage harvester direct cut grass silage" and "mower cut and then baling silage". IRL, we do not bale just after the mower job. there is some time between the mower and the baler jobs. so that the grass can loose some "water".
RealisticMain.BALE_SILAGE_MASS_FX = 0.24 -- there is no magic in real world => if the bale is weighing 1000kg at the wrapping time, it means we will get 1000kg of silage. and so, we have to take into account the BALE_GRASS_MASS_FX just above and the difference betwwen grass density and silage density

--VehicleDebug.setState(VehicleDebug.DEBUG_PHYSICS)

local version = g_modManager:getModByName(g_currentModName).version
print("**********************************************************************")
Logging.info('[MoreRealistic] Loading version %s', version)

source(Utils.getFilename("scripts/RealisticUtils.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_AIImplement.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_AIVehicleUtil.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_AnimatedVehicle.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Attachable.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_AttacherJoints.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Bale.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_BaleWrapper.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Baler.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Combine.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_ConveyorLoaderVehicle.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Cultivator.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Dashboard.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Drivable.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_DynamicMountAttacher.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_FillTypeManager.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_FillUnit.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_ForageWagon.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_FruitPreparer.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_FruitTypeManager.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_GroundReference.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_HandToolHands.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Lights.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_LoadTrigger.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_ManureBarrel.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_ManureSpreader.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Motorized.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_MountableObject.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Mower.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_ObjectChangeUtil.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Plow.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_PowerConsumer.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_RecoverVehicleEvent.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_SoundManager.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_SpeedRotatingParts.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Sprayer.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_StoreManager.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_StrawBlower.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Tedder.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_TensionBelts.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_TurnOnVehicle.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Vehicle.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_VehicleConfigurationDataAdditionalMass.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_VehicleConfigurationItemWheel.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_VehicleDebug.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_VehicleMotor.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_VehicleSystem.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Weather.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Wheel.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_WheelDebug.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_WheelPhysics.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_WheelVisualPart.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Wheels.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_WheelsUtil.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_Windrower.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_WoodCrusher.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/MR_WorkArea.lua", g_currentModDirectory))
source(Utils.getFilename("scripts/FIX_PF.lua", g_currentModDirectory))

-- load "moreRealistic" figures for tire friction vs surface and rolling resistance
MoreRealistic.RealisticUtils.loadRealTyresFrictionAndRr(g_currentModDirectory .. "data/TyresFrictionAndRrTable.xml")

-- load modified data for default vehicles
MoreRealistic.RealisticUtils.loadDefaultVehiclesModifiedData(g_currentModDirectory .. "data/overriding", "overridingDatabase.xml")

MoreRealistic.RealisticUtils.mrBaseDir = g_currentModDirectory


print(" -- loading finished -- ")
print("**********************************************************************")


function RealisticMain:loadMap(name)
    RealisticUtils.loadTerrainIdToName()
    g_currentMission.environment.weather.getGroundWetness = Utils.overwrittenFunction(g_currentMission.environment.weather.getGroundWetness, Weather.mrGetGroundWetness)
end


--allow to use the following functions :
--draw()
--update(dt)
--loadMap(name)
--deleteMap()
--mouseEvent(posX, posY,isDown, isUp, mouseKey)
--keyEvent(unicode, sym, modifier, isDown)
addModEventListener(RealisticMain)
